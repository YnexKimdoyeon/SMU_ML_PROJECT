import time

from selenium import webdriver
from selenium.webdriver.common.by import By

driver = webdriver.Chrome()
driver.get("https://www.health.kr/interaction/drug.asp")
driver.implicitly_wait(5)
with open ("file.txt", "r",encoding="UTF-8") as f:
    alist = f.readlines()
for Number,j in enumerate(alist):
    print(j)
    try:
        driver.execute_script(j)
    except:
        print("error")
        input()
    time.sleep(0.1)
    if Number == 1000:
        print("브렉")

        break
input()